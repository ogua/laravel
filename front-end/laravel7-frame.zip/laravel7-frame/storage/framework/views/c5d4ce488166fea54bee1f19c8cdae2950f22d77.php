<li class="menu-title">
    <span><?php echo e($title); ?></span>
</li>
<?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/my_class/laravel/front-end/laravel7/resources/views/components/menu-title.blade.php ENDPATH**/ ?>