<li>
    <a class="menu-item" href="{{ $link }}">
        <span>
            {{ $icon }}
            {{ $name }}
        </span>


    </a>
</li>
