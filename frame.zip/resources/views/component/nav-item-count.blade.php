<li>
    <a class="menu-item" href="{{ $link }}">
        <span>
            {{ $icon }}
            {{ $name }}
        </span>

        <span class="badge badge-pill badge-light shadow-sm">
            {{ $count }}
        </span>

    </a>
</li>
