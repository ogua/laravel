<a class="dropdown-item text-uppercase" href="{{ $link }}">
    {{ $name }}
</a>
