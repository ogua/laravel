<?php


namespace App;


class Custom
{
    public static $info =  [

        "name" => "Dashboard Frame",
        "short_name" => "Frame",
        "type" => "dashobard",
        "phone" => "",
        "address" =>"",
        "meta-img" => "f/img/meta.jpg",
        "mms-logo" => "dashboard/images/mms-logo.jpg",
        "c-logo" => "dashboard/images/logo.jpg",
        "main_css" => "dashboard/css/bootstrap.min.css",
    ];

}
