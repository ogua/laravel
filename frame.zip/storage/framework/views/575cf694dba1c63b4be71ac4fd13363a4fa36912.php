<li>
    <h5 class="text-secondary">
        <?php echo e($slot); ?>

    </h5>
</li>
<?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/main-frame/project/resources/views/component/nav-title.blade.php ENDPATH**/ ?>