
<?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/main-frame/project/resources/views/welcome.blade.php ENDPATH**/ ?>