<li>
    <a class="menu-item" href="<?php echo e($link); ?>">
        <span>
            <?php echo e($icon); ?>

            <?php echo e($name); ?>

        </span>


    </a>
</li>
<?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/main-frame/project/resources/views/component/nav-item.blade.php ENDPATH**/ ?>