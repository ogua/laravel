<!DOCTYPE html>
<html lang="en">
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">

    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">

    <title>ကြယ်ဖြူ Chat Bot</title>

    <link rel="icon" href="./ကြယ်ဖြူ Chat Bot_files/c-logo.jpg">

    <link rel="stylesheet" href="<?php echo e(asset('dashboard/css/bootstrap.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('dashboard/css/feather.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('dashboard/css/all.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('dashboard/css/animate.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('dashboard/css/summernote-bs4.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('dashboard/css/dataTables.bootstrap4.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('dashboard/css/style.css')); ?>">

</head>
<body>

<div class="container-fluid">
    <div class="row">
        <!--        aside left start -->
        <div class="col-12 col-md-6 col-lg-3 col-xl-2 vh-100 aside-menu p-0">
            <div class="aside-left bg-white px-3 pb-2 min-vh-100 shadow">
                <ul class="menu" style="list-style-type: none">
                    <li class="brand-icon">
                        <div class="d-flex justify-content-between">
                            <div class="d-flex align-items-center">
                                <img src="./ကြယ်ဖြူ Chat Bot_files/c-logo.jpg" class="brand-icon-img">
                                <small class="text-primary font-weight-bold h5 mb-0 ml-2">ကြယ်ဖြူ</small>
                            </div>
                            <button class="btn btn-light d-block d-lg-none aside-menu-close">
                                <i class="feather-x fa-2x"></i>
                            </button>
                        </div>
                    </li>
                    <li>
                        <a class="menu-item mt-3" href="https://kyalphyu.com/panel/home">
                    <span>
                        <i class="feather-home mr-1"></i>
                        Dashboard
                    </span>
                        </a>
                    </li>
                    <li>
                        <a class="menu-item active" href="https://kyalphyu.com/panel/link">
                    <span>
                        <i class="feather-link mr-1"></i>
                        Link
                    </span>
                        </a>
                    </li>
                    <li>
                        <a class="menu-item" href="https://kyalphyu.com/panel/viewer">
                    <span>
                        <i class="feather-users mr-1"></i>
                        Viewer
                    </span>
                        </a>
                    </li>
                    <li>
                        <div class="my-5"></div>
                    </li>

                    <li>
                        <h5 class="text-secondary">
                            Order Management
                        </h5>
                    </li>
                    <li>
                        <a class="menu-item" href="https://kyalphyu.com/panel/today-order">
                    <span>
                        <i class="feather-calendar mr-1"></i>
                        Today Order
                    </span>
                            <span class="badge badge-pill badge-light shadow-sm">
                        0
                    </span>
                        </a>
                    </li>
                    <li>
                        <a class="menu-item" href="https://kyalphyu.com/panel/filter-order">
                    <span>
                        <i class="feather-filter mr-1"></i>
                        Filter
                    </span>

                        </a>
                    </li>
                    <li>
                        <a class="menu-item" href="https://kyalphyu.com/panel/order">
                    <span>
                        <i class="feather-shopping-bag mr-1"></i>
                        All Order
                    </span>

                        </a>
                    </li>

                    <li>
                        <div class="my-5"></div>
                    </li>


                    <li>
                        <h5 class="text-secondary">
                            Item Management
                        </h5>
                    </li>
                    <li>
                        <a class="menu-item" href="https://kyalphyu.com/panel/item/create">
                    <span>
                        <i class="feather-plus-circle mr-1"></i>
                        Add Item
                    </span>

                        </a>
                    </li>
                    <li>
                        <a class="menu-item" href="https://kyalphyu.com/panel/item">
                    <span>
                        <i class="feather-list mr-1"></i>
                        Item List
                    </span>
                            <span class="badge badge-pill badge-light shadow-sm">
                        26
                    </span>
                        </a>
                    </li>
                    <li>
                        <a class="menu-item" href="https://kyalphyu.com/panel/collection/create">
                    <span>
                        <i class="feather-archive mr-1"></i>
                        Collection
                    </span>
                            <span class="badge badge-pill badge-light shadow-sm">
                        0
                    </span>
                        </a>
                    </li>

                    <li>
                        <div class="my-5"></div>
                    </li>
                    <li>
                        <h5 class="text-secondary">
                            Promotion Management
                        </h5>
                    </li>
                    <li>
                        <a class="menu-item" href="https://kyalphyu.com/panel/promotion/create">
                    <span>
                        <i class="feather-gift mr-1"></i>
                        Add Promotion
                    </span>

                        </a>
                    </li>
                    <li>
                        <a class="menu-item" href="https://kyalphyu.com/panel/promotion">
                    <span>
                        <i class="feather-server mr-1"></i>
                        Promotion List
                    </span>
                            <span class="badge badge-pill badge-light shadow-sm">
                        0
                    </span>
                        </a>
                    </li>


                    <li>
                        <div class="my-5"></div>
                    </li>

                    <li>
                        <h5 class="text-secondary">
                            User Management
                        </h5>
                    </li>
                    <li>
                        <a class="menu-item" href="https://kyalphyu.com/panel/add-staff">
                    <span>
                        <i class="feather-user-plus mr-1"></i>
                        Add Staff
                    </span>

                        </a>
                    </li>
                    <li>
                        <a class="menu-item" href="https://kyalphyu.com/panel/staff-list">
                    <span>
                        <i class="fas fa-users mr-1"></i>
                        Staff List
                    </span>
                            <span class="badge badge-pill badge-light shadow-sm">
                        1
                    </span>
                        </a>
                    </li>
                    <li>
                        <a class="menu-item" href="https://kyalphyu.com/panel/customer-list">
                    <span>
                        <i class="feather-user-check mr-1"></i>
                        Customer List
                    </span>
                            <span class="badge badge-pill badge-light shadow-sm">
                        8263
                    </span>
                        </a>
                    </li>
                    <li>
                        <a class="menu-item" href="https://kyalphyu.com/panel/customer-ban-list">
                    <span>
                        <i class="feather-user-minus mr-1"></i>
                        Ban Customer
                    </span>
                            <span class="badge badge-pill badge-light shadow-sm">
                        1
                    </span>
                        </a>
                    </li>
                    <li>
                        <a class="menu-item" href="https://kyalphyu.com/panel/profile">
                    <span>
                        <i class="far fa-user-circle mr-1"></i>
                        Your Profile
                    </span>

                        </a>
                    </li>
                    <li>
                        <div class="my-5"></div>
                    </li>


                    <li>
                        <h5 class="text-secondary">
                            Configuration
                        </h5>
                    </li>
                    <li>
                        <a class="menu-item" href="https://kyalphyu.com/panel/category/create">
                    <span>
                        <i class="feather-package mr-1"></i>
                        Main Category
                    </span>
                            <span class="badge badge-pill badge-light shadow-sm">
                        10
                    </span>
                        </a>
                    </li>
                    <li>
                        <a class="menu-item" href="https://kyalphyu.com/panel/sub-category/create">
                    <span>
                        <i class="feather-layers mr-1"></i>
                        Sub Category
                    </span>
                            <span class="badge badge-pill badge-light shadow-sm">
                        10
                    </span>
                        </a>
                    </li>
                    <li>
                        <a class="menu-item" href="https://kyalphyu.com/panel/unit/create">
                    <span>
                        <i class="feather-save mr-1"></i>
                        Item Unit
                    </span>
                            <span class="badge badge-pill badge-light shadow-sm">
                        12
                    </span>
                        </a>
                    </li>

                    <li>
                        <a class="menu-item" href="https://kyalphyu.com/panel/sd/create">
                    <span>
                        <i class="feather-map-pin mr-1"></i>
                        State/Division
                    </span>
                            <span class="badge badge-pill badge-light shadow-sm">
                        19
                    </span>
                        </a>
                    </li>

                    <li>
                        <a class="menu-item" href="https://kyalphyu.com/panel/payment/create">
                    <span>
                        <i class="fas fa-wallet mr-1"></i>
                        Payment Method
                    </span>
                            <span class="badge badge-pill badge-light shadow-sm">
                        3
                    </span>
                        </a>
                    </li>
                    <li>
                        <div class="my-5"></div>
                    </li>


                    <li>
                        <a class="menu-item alert-danger text-danger"
                           onclick="event.preventDefault();document.getElementById(&#39;logout-form&#39;).submit();"
                           href="https://kyalphyu.com/panel/link#">
                    <span>
                        <i class="fas fa-lock"></i>
                        Logout
                    </span>
                        </a>
                    </li>
                </ul>
            </div>


        </div>
        <!--        aside left end -->
        <div class="col-12 col-md-12 col-lg-9 col-xl-10 vh-100 mt-2 content">
            <div class="container-fluid">
                <div class="row">


                    <!-- content start-->
                    <div class="col-12 px-0">
                        <div
                            class="p-2 d-flex px-0 bg-primary shadow-sm rounded justify-content-between align-items-center header animate__animated animate__fadeIn">
                            <button class="btn btn-primary d-inline d-lg-none aside-menu-open mb-0">
                                <i class="feather-menu fa-2x mb-0"></i>
                            </button>
                            <form class="d-none d-md-block" action="https://kyalphyu.com/panel/order">

                                <div class="form-inline">

                                    <div class="dropdown mr-3">
                                        <a class="btn btn-light bg-transparent text-white border-0 dropdown-toggle text-uppercase"
                                           href="https://kyalphyu.com/panel/link#" role="button" id="dropdownMenuLink"
                                           data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                            <i class="fas fa-plus-circle"></i> Quick Add
                                        </a>

                                        <div class="dropdown-menu" aria-labelledby="dropdownMenuLink">
                                            <a class="dropdown-item text-uppercase"
                                               href="https://kyalphyu.com/panel/item/create">
                                                Add Item
                                            </a>
                                            <a class="dropdown-item text-uppercase"
                                               href="https://kyalphyu.com/panel/promotion/create">
                                                Add Promotion
                                            </a>
                                            <a class="dropdown-item text-uppercase"
                                               href="https://kyalphyu.com/panel/category/create">
                                                Add Main Cat
                                            </a>

                                            <a class="dropdown-item text-uppercase"
                                               href="https://kyalphyu.com/panel/sub-category/create">
                                                Add Sub Cat
                                            </a>

                                            <a class="dropdown-item text-uppercase"
                                               href="https://kyalphyu.com/panel/unit/create">
                                                Add Unit
                                            </a>
                                        </div>
                                    </div>
                                    <div class="form-group mr-2">
                                        <input type="text" class="form-control" name="orderCode"
                                               placeholder="Find Order" required="">
                                    </div>
                                    <div class="form-group">
                                        <button class="btn btn-light">
                                            <i class="fa fa-search text-primary"></i>
                                        </button>
                                    </div>
                                </div>
                            </form>
                            <div class="dropdown">
                                <a class="btn btn-light bg-transparent text-white border-0 dropdown-toggle"
                                   href="https://kyalphyu.com/panel/link#" role="button" id="dropdownMenuLink"
                                   data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                    <img src="./ကြယ်ဖြူ Chat Bot_files/profile_default.png" class="rounded-circle"
                                         style="width: 30px" alt="">
                                    <span class="d-none d-lg-inline">
                    Admin
                </span>
                                </a>

                                <div class="dropdown-menu" aria-labelledby="dropdownMenuLink">
                                    <a class="dropdown-item" target="_blank"
                                       href="https://premium70.web-hosting.com:2096/">
                                        <i class="feather-mail"></i>
                                        EMail
                                    </a>
                                    <a class="dropdown-item" target="_blank"
                                       href="https://www.facebook.com/kyalphyufashion/">
                                        <i class="feather-facebook"></i>
                                        Facebook
                                    </a>
                                    <a class="dropdown-item" target="_blank"
                                       href="https://manychat.com/fb209730/dashboard">
                                        <i class="feather-message-square "></i>
                                        ManyChat
                                    </a>
                                    <div class="dropdown-divider"></div>
                                    <a class="dropdown-item" href="https://kyalphyu.com/panel/link#">

                                    </a><a class="dropdown-item" href="https://kyalphyu.com/logout"
                                           onclick="event.preventDefault();document.getElementById(&#39;logout-form&#39;).submit();">
                                        <i class="fa fa-lock"></i> Logout
                                    </a>

                                    <form id="logout-form" action="https://kyalphyu.com/logout" method="POST"
                                          style="display: none;">
                                        <input type="hidden" name="_token"
                                               value="Zf75XgigdOe0D2rp1KRvhvxB3X3wgxKdzONb8KR5"></form>

                                </div>
                            </div>
                        </div>
                        <div class="container-fluid">
                            <div class="row">
                                <div class="col-12 loader" style="display: none;">
                                    <div class="d-flex justify-content-center align-items-center vh-100 ">
                                        <div class="spinner-grow text-primary" role="status">
                                            <span class="sr-only">Loading...</span>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-12 px-0 py-3 min-vh-100 page-content" style="">
                                    <!--                                    card area start-->
                                    <div class="row">
                                        <div class="col-12">
                                            <div class="pb-3">
                                                <a class="text-uppercase" href="https://kyalphyu.com/panel/home"><i
                                                        class="feather-home"></i></a>
                                                <span class="mx-2"><i class="fas fa-angle-right"></i></span>
                                                <span class="text-uppercase">Link</span>
                                            </div>
                                        </div>
                                        <div class="col-lg-12 col-xl-8">
                                            <div class="card">
                                                <div class="card-body">
                                                    <div class="d-flex justify-content-between align-items-center mb-3">
                                                        <h5 class="mb-0 text-uppercase font-weight-bold">
                                                            <i class="feather-package text-primary"></i>
                                                            Make Link
                                                        </h5>
                                                        <div class="">
                                                            <button
                                                                class="btn btn-outline-secondary btn-sm btn-maximize"
                                                                title="Maximize">
                                                                <i class="fas fa-expand-alt fa-fw"></i>
                                                            </button>
                                                        </div>
                                                    </div>
                                                    <hr>
                                                    <form action="https://kyalphyu.com/panel/link" id="single">
                                                        <p class="text-secondary font-weight-bold mb-0">Item Detail
                                                            Link</p>
                                                        <div class="form-inline">
                                                            <label class="d-none d-md-inline-block" for="">https://kyalphyu.com/single/</label>
                                                            <input type="number" min="1" id="itemId"
                                                                   style="width: 100px"
                                                                   class="form-control form-control-sm mx-2"
                                                                   placeholder="Item ID" required="">
                                                            <button class="btn btn-outline-primary btn-sm">
                                                                <i class="feather-link"></i>
                                                                Open
                                                            </button>
                                                        </div>
                                                    </form>
                                                    <div class="my-5"></div>
                                                    <form action="https://kyalphyu.com/panel/link" id="cat">
                                                        <p class="text-secondary font-weight-bold mb-0">Category based
                                                            Item Link</p>
                                                        <div class="form-inline">
                                                            <label class="d-none d-md-inline-block" for="">https://kyalphyu.com/category/</label>
                                                            <input type="number" min="1" id="catId" style="width: 100px"
                                                                   class="form-control form-control-sm mx-2"
                                                                   placeholder="Category ID" required="">
                                                            <button class="btn btn-outline-primary btn-sm">
                                                                <i class="feather-link"></i>
                                                                Open
                                                            </button>
                                                        </div>
                                                    </form>
                                                    <div class="my-5"></div>
                                                    <form action="https://kyalphyu.com/panel/link" id="ics">
                                                        <p class="text-secondary font-weight-bold mb-0">Category and Sub
                                                            Category Link</p>
                                                        <div class="form-inline">
                                                            <label class="d-none d-md-inline-block" for="">https://kyalphyu.com/category-sub/</label>
                                                            <input type="number" min="1" id="ic" style="width: 100px"
                                                                   class="form-control form-control-sm ml-2"
                                                                   placeholder="Category ID" required="">
                                                            <label for="" class="mx-2">/</label>
                                                            <input type="number" min="1" id="icsId" style="width: 100px"
                                                                   class="form-control form-control-sm mr-2"
                                                                   placeholder="Sub Cat ID" required="">
                                                            <button class="btn btn-outline-primary btn-sm">
                                                                <i class="feather-link"></i>
                                                                Open
                                                            </button>
                                                        </div>
                                                    </form>

                                                    <div class="my-5"></div>
                                                    <form action="https://kyalphyu.com/panel/link" id="ics">
                                                        <p class="text-secondary font-weight-bold mb-0">Promotion
                                                            Links</p>
                                                        <div class="form-group">
                                                            <p>No Promotion</p>
                                                        </div>
                                                    </form>

                                                    <div class="my-5"></div>
                                                    <form action="https://kyalphyu.com/panel/link" id="ics">
                                                        <p class="text-secondary font-weight-bold mb-0">Customer Order
                                                            Link</p>
                                                        <div class="form-group">

                                                            <input type="text" id="ic"
                                                                   value="https://kyalphyu.com/order-list"
                                                                   class="form-control" placeholder="Category ID"
                                                                   required="">

                                                        </div>
                                                    </form>
                                                </div>
                                            </div>
                                        </div>

                                    </div>
                                    <!--                                    card area end-->
                                </div>

                                <div class="col-12 p-0 mt-3">
                                    <div
                                        class="alert-secondary  rounded d-flex flex-column flex-md-row justify-content-between text-secondary py-2 px-3">
                                        <div>
                                            Copy Right @ ကြယ်ဖြူ 2020
                                        </div>
                                        <div>
                                            Developed By <a class="text-primary font-weight-bold"
                                                            href="http://mms-it.com/">MMS IT</a>
                                        </div>
                                    </div>
                                </div>

                            </div>
                        </div>
                    </div>
                    <!--content end                    -->

                </div>
            </div>
        </div>
    </div>
</div>


<!-- Scripts -->
<script src="<?php echo e(asset('dashboard/js//jquery.js')); ?>"></script>
<script src="<?php echo e(asset('dashboard/js//bootstrap.js')); ?>"></script>
<script src="<?php echo e(asset('dashboard/js//jquery.dataTables.min.js')); ?>"></script>
<script src="<?php echo e(asset('dashboard/js//dataTables.bootstrap4.min.js')); ?>"></script>
<script src="<?php echo e(asset('dashboard/js//app.js')); ?>"></script>

<script>
    $(".dataTables_length,.dataTables_filter,.dataTable,.dataTables_paginate,.dataTables_info").parent().addClass("px-0");
</script>


</body>
</html>
<?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/main-frame/project/resources/views/dashboard/master.blade.php ENDPATH**/ ?>