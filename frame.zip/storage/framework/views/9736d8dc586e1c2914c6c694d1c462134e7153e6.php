<li>
    <a class="menu-item" href="<?php echo e($link); ?>">
        <span>
            <?php echo e($icon); ?>

            <?php echo e($name); ?>

        </span>

        <span class="badge badge-pill badge-light shadow-sm">
            <?php echo e($count); ?>

        </span>

    </a>
</li>
<?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/main-frame/project/resources/views/component/nav-item-count.blade.php ENDPATH**/ ?>