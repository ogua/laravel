<li>
    <div class="my-5"></div>
</li>
<?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/main-frame/project/resources/views/component/nav-spacer.blade.php ENDPATH**/ ?>