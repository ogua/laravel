<a class="dropdown-item text-uppercase" href="<?php echo e($link); ?>">
    <?php echo e($name); ?>

</a>
<?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/main-frame/project/resources/views/component/header-qa.blade.php ENDPATH**/ ?>